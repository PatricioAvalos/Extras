/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller4app;

/**
 *
 * @author favya
 */
public interface IApp {
    

    public void leerInscripciones();
    public void leerAsignaturas();
    public void leerPersonas();
    public void RF1();
    public void RF2();
    public void RF3();
    public void RF4();
    public void RF5();
    public void RF6(); 
    
}
